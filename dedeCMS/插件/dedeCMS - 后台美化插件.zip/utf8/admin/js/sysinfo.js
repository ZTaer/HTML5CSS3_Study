layui.config({
	base : "../publics/layui/lay/modules/"
}).use(['form','element','layer','jquery'],function(){
	var form = layui.form(),
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		element = layui.element(),
		$ = layui.jquery;
	
	$(document).ready(function(){	
		var clipboardSnippets = new ClipboardJS('.zerocopy',{
			target: function(trigger){
				return trigger;
			}
		});
		clipboardSnippets.on('success', function(e){
			e.clearSelection();
			layer.msg('复制成功', {icon:1,time:1000});
		});
		clipboardSnippets.on('error', function(e){
			layer.msg('复制失败，请手动复制', {icon:2,time:1000});
			e.clearSelection();
		});
	});
	
	//修改系统变量
	form.on('submit(submit)', function(data){
		var param = data.field;
		$.post(data.form.action, param, function(data){
			if(data.status == 1){
				layer.msg(data.msg, {
					icon: 1,
					time: data.time
				}, function(){
					if(data.gourl != '-1')
					location.href = data.gourl;
				});
			}else{
				layer.alert(data.msg, {
					icon: 2
				});
			}
		});
		return false;
	});
	//删除变量
	$("body").on("click",".sys_del",function(){
		var _this = $(this);
		layer.confirm('确定删除？',{icon:3, title:'提示信息'},function(index){
			$.post('sys_info.php?dopost=del', {'aid':_this.attr("data-id")}, function(data){
				if(data.status == 1){
					layer.msg(data.msg, {
						icon: 1,
						time: 1000
					}, function(){
						if(data.gourl != '-1')
						location.href = data.gourl;
					});
					layer.close(index);
				}else{
					layer.alert(data.msg, {
						icon: 2
					});
				}
			});
		});
	})
})
