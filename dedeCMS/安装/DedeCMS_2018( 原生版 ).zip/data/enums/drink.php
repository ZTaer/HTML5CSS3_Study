<?php
global $em_drinks;
$em_drinks = array();
$em_drinks['1'] = '不喝酒';
$em_drinks['2'] = '偶尔喝一点';
$em_drinks['3'] = '喝得很凶';
?>