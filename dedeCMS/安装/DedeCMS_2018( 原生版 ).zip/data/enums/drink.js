<!--
em_drinks=new Array();
em_drinks[1]='不喝酒';
em_drinks[2]='偶尔喝一点';
em_drinks[3]='喝得很凶';
-->