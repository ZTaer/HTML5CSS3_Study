<?php
//小助手配置项
$cfg_helper_autoload = array
(
        'charset',    /* 编码小助手 */
        'channelunit',/* 模型单元小助手 */ 
        'string',     /* 字符串小助手 */
        'time',       /* 日期小助手 */
        'file',       /* 文件小助手 */
        'util',       /* 单元小助手 */
        'validate',   /* 数据验证小助手 */
        'filter',     /* 过滤器小助手 */
        'cookie',     /* cookies小助手 */
        'debug',      /* 调试小助手 */
        'archive',    /* 文档小助手 */
        'upload',     /* 上传小助手 */
        'extend',     /* 扩展小助手 */
);
?>
